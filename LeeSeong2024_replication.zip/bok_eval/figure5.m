clear
clc

load eval_data.mat

%%%%%
time = evaldata.time;
ecpi0 = -evaldata.cpi0+evaldata.realized_cpi;
ecpi1 = -evaldata.cpi1+evaldata.realized_cpi;
ecpi2 = -evaldata.cpi2+evaldata.realized_cpi;
ecpi3 = -evaldata.cpi3+evaldata.realized_cpi;
ecpi4 = -evaldata.cpi4+evaldata.realized_cpi;
ecpi5 = -evaldata.cpi5+evaldata.realized_cpi;
ecpi6 = -evaldata.cpi6+evaldata.realized_cpi;
ecpi = ([ecpi3,ecpi2,ecpi1,ecpi0])';

figure("Position",[300,300,1000,500])
bar(time,ecpi)
pbaspect([2 1 1])
xlim([2012,2025])
ylim([-3,3])
title 'Inflation rate Forecast Error'
xticks([2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025])
legend 'h=3' 'h=2' 'h=1' 'h=0'
grid on;