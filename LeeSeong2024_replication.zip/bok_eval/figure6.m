clear
clc

load eval_data.mat;

% Simulated Realization-Forecast
A = -1:0.1:6; %forecast
A = A';
LPF = A;
F = 0.6+0.8*A; %realization
e = mvnrnd(0,1,71);
f = 0.6+0.8*A+e;

pbaspect([1 1 1]);hold on;
grid on;
plot(A,F,'b--');
plot(A,LPF,'r');
scatter(A,f,'k','o');hold off;

mean(f)

% realization-forecast plot (h=0)
y = evaldata.realized_cpi;
x = evaldata.cpi0;
W0 = [y,x];
W0 = rmmissing(W0);
X = [ones(size(W0,1),1),W0(:,2)];
RLbeta = (X'*X)\(X'*W0(:,1));
RL0 = [ones(size(A,1),1),A]*RLbeta;


figure (1)
plot(LPF,A,'r'); hold on;
plot(RL0,A,'b--');
scatter(W0(:,2),W0(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs
xlabel Forecast
ylabel Realization
title h=0
hold off;
mean(W0(:,1))
figure(2)
histogram(W0(:,1)-W0(:,2),10)
pbaspect([1 1 1])
title 'Forecast Error h=0'
subtitle Histogram


% realization-forecast plot (h=1)
y = evaldata.realized_cpi;
x = evaldata.cpi1;
W1 = [y,x];
W1 = rmmissing(W1);
X = [ones(size(W1,1),1),W1(:,2)];
RLbeta = (X'*X)\(X'*W1(:,1));
RL1 = [ones(size(A,1),1),A]*RLbeta;


figure (1)
plot(A,LPF,'r'); hold on;
plot(A,RL1,'b--');
scatter(W1(:,2),W1(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs
xlabel Realization
ylabel Forecast
title h=1
hold off;
mean(W1(:,1))
figure(2)
histogram(W1(:,1)-W1(:,2),10)
pbaspect([1 1 1])
title 'Forecast Error h=1'
subtitle Histogram

% realization-forecast plot (h=2)
y = evaldata.realized_cpi;
x = evaldata.cpi2;
W2 = [y,x];
W2 = rmmissing(W2);
X = [ones(size(W2,1),1),W2(:,2)];
RLbeta = (X'*X)\(X'*W2(:,1));
RL2 = [ones(size(A,1),1),A]*RLbeta;


figure (1)
plot(A,LPF,'r'); hold on;
plot(A,RL2,'b--');
scatter(W2(:,2),W2(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs
xlabel Realization
ylabel Forecast
title h=2
hold off;
mean(W2(:,1))
figure(2)
histogram(W2(:,1)-W2(:,2),10)
pbaspect([1 1 1])
title 'Forecast Error h=2'
subtitle Histogram


% realization-forecast plot (h=3)
y = evaldata.realized_cpi;
x = evaldata.cpi3;
W3 = [y,x];
W3 = rmmissing(W3);
X = [ones(size(W3,1),1),W3(:,2)];
RLbeta = (X'*X)\(X'*W3(:,1));
RL3 = [ones(size(A,1),1),A]*RLbeta;


figure (1)
plot(A,LPF,'r'); hold on;
plot(A,RL3,'b--');
scatter(W3(:,2),W3(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs
xlabel Realization
ylabel Forecast
title h=3
hold off;
mean(W3(:,1))
figure(2)
histogram(W3(:,1)-W3(:,2),10)
pbaspect([1 1 1])
title 'Forecast Error h=3'
subtitle Histogram

% realization-forecast plot (h=4)
y = evaldata.realized_cpi;
x = evaldata.cpi4;
W4 = [y,x];
W4 = rmmissing(W4);
X = [ones(size(W4,1),1),W4(:,2)];
RLbeta = (X'*X)\(X'*W4(:,1));
RL4 = [ones(size(A,1),1),A]*RLbeta;


figure (1)
plot(A,LPF,'r'); hold on;
plot(A,RL4,'b--');
scatter(W4(:,2),W4(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs
xlabel Realization
ylabel Forecast
title h=4
hold off;
mean(W4(:,1))
figure(2)
histogram(W4(:,1)-W4(:,2),10)
pbaspect([1 1 1])
title 'Forecast Error h=4'
subtitle Histogram


load pool_data.mat
% realization-forecast plot (pooled approach)
y = pooldatav2.realized_cpi;
x = pooldatav2.cpi_f;
Wp = [y,x];
Wp = rmmissing(Wp);
X = [ones(size(Wp,1),1),Wp(:,2)];
RLbeta = (X'*X)\(X'*Wp(:,1));
RL_pool = [ones(size(A,1),1),A]*RLbeta;


figure (1)
plot(A,LPF,'r'); hold on;
plot(A,RL_pool,'b--');
scatter(Wp(:,2),Wp(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs
xlabel Realization
ylabel Forecast
title 'Pooled approach'
hold off;
mean(Wp(:,1))
figure(2)
histogram(Wp(:,1)-Wp(:,2),10)
pbaspect([1 1 1])
title 'Forecast Error Pooled approach'
subtitle Histogram


% Figure for all the horizons and pooled approach.

figure('Position',[100 100 1200 800])
subplot(2,3,1)
xlim ([-1,6]); hold on;
xticks ([-1,0,1,2,mean(W0(:,2)),3,4,5,6])
yticks ([-1,0,1,2,3,4,5,6])
ylim ([-1,6]);
plot(A,LPF,'r');
plot(A,RL0,'b--');
scatter(W0(:,2),W0(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs Location southeast
xlabel Forecast
ylabel Realization
title h=0
hold off;

subplot(2,3,2)
xlim ([-1,6]); hold on;
xticks ([-1,0,1,2,mean(W1(:,2)),3,4,5,6])
yticks ([-1,0,1,2,3,4,5,6])
ylim ([-1,6]);
plot(A,LPF,'r');
plot(A,RL1,'b--');
scatter(W1(:,2),W1(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs Location southeast
xlabel Forecast
ylabel Realization
title h=1
hold off;

subplot(2,3,3)
xlim ([-1,6]); hold on;
xticks ([-1,0,1,2,mean(W2(:,2)),3,4,5,6])
yticks ([-1,0,1,2,3,4,5,6])
ylim ([-1,6]);
plot(A,LPF,'r');
plot(A,RL2,'b--');
scatter(W2(:,2),W2(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs Location southeast
xlabel Forecast
ylabel Realization
title h=2
hold off;

subplot(2,3,4)
xlim ([-1,6]); hold on;
xticks ([-1,0,1,2,mean(W3(:,2)),3,4,5,6])
yticks ([-1,0,1,2,3,4,5,6])
ylim ([-1,6]);
plot(A,LPF,'r');
plot(A,RL3,'b--');
scatter(W3(:,2),W3(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs Location southeast
xlabel Forecast
ylabel Realization
title h=3
hold off;

subplot(2,3,5)
xlim ([-1,6]); hold on;
xticks ([-1,0,1,2,mean(W4(:,2)),3,4,5,6])
yticks ([-1,0,1,2,3,4,5,6])
ylim ([-1,6]);
plot(A,LPF,'r');
plot(A,RL4,'b--');
scatter(W4(:,2),W4(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs Location southeast
xlabel Forecast
ylabel Realization
title h=4
hold off;

subplot(2,3,6)
xlim ([-1,6]); hold on;
xticks ([-1,0,1,2,mean(Wp(:,2)),3,4,5,6])
yticks ([-1,0,1,2,3,4,5,6])
ylim ([-1,6]);
plot(A,LPF,'r');
plot(A,RL_pool,'b--');
scatter(Wp(:,2),Wp(:,1),'k','o'); 
pbaspect([1 1 1]);grid on;
legend LPF RL obs Location southeast
xlabel Forecast
ylabel Realization
title 'Pooled approach'
hold off;