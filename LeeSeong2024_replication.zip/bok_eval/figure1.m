clear
clc

load gdp_plot.mat

figure("Position",[300,300,1000,500])
plot(gdpgrowthrate.t,gdpgrowthrate.realized,'r-o','DisplayName','gdpgrowthrate.realized');hold on;
plot(gdpgrowthrate.t,gdpgrowthrate.VarName3,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName4,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName5,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName6,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName7,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName8,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName9,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName10,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName11,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName12,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName13,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName14,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName15,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName16,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName17,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName18,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName19,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName20,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName21,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName22,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName23,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName24,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName25,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName26,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName27,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName28,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName29,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName30,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName31,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName32,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName33,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName34,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName35,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName36,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName37,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName38,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName39,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName40,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName41,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName42,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName43,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName44,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName45,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName46,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName47,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName48,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName49,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName50,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName51,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName52,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName53,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName54,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName55,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName56,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName57,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName58,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName59,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName60,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName61,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName62,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName63,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName64,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName65,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName66,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName67,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName68,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName69,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName70,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName71,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName72,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName73,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName74,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName75,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName76,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName77,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName78,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName79,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName80,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName81,'b--x');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName82,'c-.^');
plot(gdpgrowthrate.t,gdpgrowthrate.VarName83,'b--x');
hold off;
pbaspect([2 1 1])
xlim([2012,2026])
ylim([-2,6])
title 'GDP growth rate'
xticks([2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025,2026])
legend 'Actual growth rate' 'Second issue of the half-year' 'First issue of the half-year'

