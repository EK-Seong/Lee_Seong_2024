function BiasCorrection = MZ_BC(W,BC_forecast,forecast,T,max_window,h)
    if h < 2
        u = 1;
    elseif h < 4
        u = 2;
    else
        u = 3;
    end

    for w = 2:max_window
        for t = 1:T
            % if there is no forecast, then do nothing. Then the corresponding 
            % BC_forecast will remain NaN.
            if isnan(forecast(t,1))
                disp('No forecast at t=');disp(t)
                continue
            % if there is, then we check whether we have enough data points. 
            % We first search for the latest data point.
            else
                k=1; % Initializing the array number.
                cur_diff = (t-u)-W(k,3); % If cur_diff is negative, it means that 
                % we have crossed the threshold t-u(available info set at t).
                if cur_diff < 0
                    k=0; % k=0 means that we failed to find any data point.
                else
                    while k < t
                        nex_diff = (t-u)-W(k+1,3);
                        if nex_diff < 0
                            break
                        else
                            cur_diff = nex_diff;
                            k = k+1;
                        end
                    end
                    if k == t-u+1   % If the while loop has arrived the last loop, 
                        % then we adjust k.
                        k = k-1;
                    end
                end
                % Now we have the latest observation k. Next,
                % we check whether we lack of observations.
                if (k == 0)
                    disp('No data points to estimate mean error at t=');disp([t,k,w])
                    continue
                % If we have enough data points to estimate AR(1) coef alpha,
                % then
                else
                    if k < w
                        disp('With smaller sample size of ');disp(k)
                        Y = W(1:k,1);
                        X = [ones(size(Y,1),1),W(1:k,2)];
                        beta0 = (X'*X)\(X'*Y);
                    else
                        Y = W(k-(w)+1:k,1);
                        X = [ones(size(Y,1),1),W(k-w+1:k,2)];
                        beta0 = (X'*X)\(X'*Y);
                    end
                end
                BC_forecast(t,w-1) = round(beta0(1,1)+beta0(2,1)*forecast(t,1),1);
            end
        end
    end
    
    BiasCorrection=BC_forecast;

end