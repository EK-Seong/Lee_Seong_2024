clear
clc

load eval_data.mat

time = evaldata.time;

egdp01 = -evaldata.gdp01+evaldata.realized_gdp;
egdp0 = -evaldata.gdp0+evaldata.realized_gdp;
egdp1 = -evaldata.gdp1+evaldata.realized_gdp;
egdp2 = -evaldata.gdp2+evaldata.realized_gdp;
egdp3 = -evaldata.gdp3+evaldata.realized_gdp;
egdp4 = -evaldata.gdp4+evaldata.realized_gdp;
egdp5 = -evaldata.gdp5+evaldata.realized_gdp;
egdp6 = -evaldata.gdp6+evaldata.realized_gdp;
egdp = [egdp6,egdp5,egdp4,egdp3,egdp2,egdp1,egdp0,egdp01];

figure("Position",[300,300,1000,500])
bar(time,egdp(:,end-3:end))
pbaspect([2 1 1])
xlim([2012,2024])
ylim([-3,2])
title 'Growth rate Forecast Error'
xticks([2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025])
legend 'h=3' 'h=2' 'h=1' 'h=0'
grid on;