% Code for Figure 7
% Searching for the optimal window size of each bias correction strategy

% AR(1) 특성을 이용하므로 window size는 적어도 2 이상이어야 alpha를 계산할 수 있다. t기 거시변수를 전망하였을 때 h=0,1의 경우에는 t-1기의 전망오차를 사용하여 t기의 전망오차를 추정한다. h=2,3의 경우에는 t-2기의 전망오차를 사용하며, h=4,5의 경우에는 t-3기를 사용한다. h=0,1 그리고 w=2인 경우 초기 관측치 2개를 사용해야 하므로 t=3부터 전망오차를 추정하게 된다. h=2,3 w=2인 경우에는 같은 이유로 t=4부터 시작한다. h=4,5는 t=5이다.

clear
clc

load eval_data.mat

time = evaldata.time;
array_num = (1:size(time,1))';

ecpi0 = evaldata.cpi0-evaldata.realized_cpi;
ecpi1 = evaldata.cpi1-evaldata.realized_cpi;
ecpi2 = evaldata.cpi2-evaldata.realized_cpi;
ecpi3 = evaldata.cpi3-evaldata.realized_cpi;
ecpi4 = evaldata.cpi4-evaldata.realized_cpi;
ecpi5 = evaldata.cpi5-evaldata.realized_cpi;
ecpi6 = evaldata.cpi6-evaldata.realized_cpi;
ecpi = [array_num,ecpi0,ecpi1,ecpi2,ecpi3,ecpi4,ecpi5];
lag_ecpi = lagmatrix(ecpi,1);

ecpi0 = [array_num,ecpi0];
ecpi1 = [array_num,ecpi1];
ecpi2 = [array_num,ecpi2];
ecpi3 = [array_num,ecpi3];
ecpi4 = [array_num,ecpi4];
ecpi5 = [array_num,ecpi5];


cpi0 = evaldata.cpi0;
cpi1 = evaldata.cpi1;
cpi2 = evaldata.cpi2;
cpi3 = evaldata.cpi3;
cpi4 = evaldata.cpi4;
cpi5 = evaldata.cpi5;
cpi = [time,cpi0,cpi1,cpi2,cpi3,cpi4,cpi5];

realized_cpi = evaldata.realized_cpi;

T = size(time,1);       % allocating sample size to T
max_window0 = 20;        % allocating maximum window size
max_window1 = 20;
max_window2 = 20;
max_window3 = 20;
window0 = 2:max_window0;  % array of window sizes from 2 to max_window => for plotting rmse
window1 = 2:max_window1;
window2 = 2:max_window2;
window3 = 2:max_window3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Allocating empty matrices for "bias corrected forecasts with h = 0,1"%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BC_forecast0 = NaN(T,max_window0-1);
BC_forecast1 = NaN(T,max_window1-1);

% New predictions with alternative AR(1) model, and computing rmse of the
% alternative for each window size.
% We use past w data points (data point = pair of original and lagged
% values).

W0 = [ecpi(:,2),lag_ecpi(:,2),array_num];
W0 = rmmissing(W0);
W1 = [ecpi(:,3),lag_ecpi(:,3),array_num];
W1 = rmmissing(W1);

BC_forecast0 = AR1_BC(W0,BC_forecast0,cpi0,ecpi0,T,max_window0,0);
BC_forecast1 = AR1_BC(W1,BC_forecast1,cpi1,ecpi1,T,max_window1,1);


% We restrict the validation set to be 2012-2024, to preserve the data set
% size for each window size w. For earlier periods, there are missing
% points. Hence, to evaluate and compare fairly the window sizes we choose
% the data period that is balanced.
subsample0 = time >=2000.5 & time <=2024;   
rmse0 = rmse(BC_forecast0(subsample0,:),realized_cpi(subsample0,1),1,"omitmissing");
rmse0_bok = rmse(cpi0(subsample0,1),realized_cpi(subsample0,1),1,"omitmissing");
rrmse0 = rmse0./rmse0_bok;
subsample1 = time >=2013.5 & time <=2024;
rmse1 = rmse(BC_forecast1(subsample1,:),realized_cpi(subsample1,:),1,"omitmissing");
rmse1_bok = rmse(cpi1(subsample1,1),realized_cpi(subsample1,1),1,"omitmissing");
rrmse1 = rmse1./rmse1_bok;

% for h = 2,3

BC_forecast2 = NaN(T,max_window2-1);
BC_forecast3 = NaN(T,max_window3-1);
W2 = [ecpi(:,4),lag_ecpi(:,4),array_num];
W2 = rmmissing(W2);
W3 = [ecpi(:,5),lag_ecpi(:,5),array_num];
W3 = rmmissing(W3);

BC_forecast2 = AR1_BC(W2,BC_forecast2,cpi2,ecpi2,T,max_window2,2);
BC_forecast3 = AR1_BC(W3,BC_forecast3,cpi3,ecpi3,T,max_window3,3);

subsample2 = time >=2003 & time <=2024.5;
subsample3 = time >=2014.5 & time <=2024.5;

rmse2 = rmse(BC_forecast2(subsample2,:),realized_cpi(subsample2,1),1,"omitmissing");
rmse2_bok = rmse(cpi2(subsample2,1),realized_cpi(subsample2,1),1,"omitmissing");
rrmse2 = rmse2./rmse2_bok;

rmse3 = rmse(BC_forecast3(subsample3,:),realized_cpi(subsample3,1),1,"omitmissing");
rmse3_bok = rmse(cpi3(subsample3,1),realized_cpi(subsample3,1),1,"omitmissing");
rrmse3 = rmse3./rmse3_bok;


figure("Position",[100 100 1200 800])
subplot(2,2,1)
plot(window0,rrmse0(1,:),'k-o'); hold on;
grid on;
xticks ([4 5 10 15 20])
xlim([4 max_window0])
ylim([0.6 1.4])
ylabel 'RMSE'
title 'h=0'
subplot(2,2,2)
plot(window1,rrmse1(1,:),'k-o'); hold on;
grid on;
xticks ([4 5 10 15 20])
xlim([4 max_window1])
ylim([0.8 1.6])
title 'h=1'
subplot(2,2,3)
plot(window2,rrmse2(1,:),'k-o'); hold on;
grid on;
xticks ([4 5 10 15 20])
xlim([4 max_window2])
ylim([0.8 1.6])
ylabel 'RMSE'
xlabel 'window size'
title 'h=2'
subplot(2,2,4)
plot(window3,rrmse3(1,:),'k-o'); hold on;
grid on;
xticks ([4 5 10 15 20])
xlim([4 max_window3])
ylim([0.8 1.6])
xlabel 'window size'
title 'h=3'

%% save the AR(1) bias-corrected forecasts with optimal window sizes

optwin0 = 20;
optwin1 = 20;
optwin2 = 20;
optwin3 = 20;

opt_BC_forecast = [BC_forecast0(:,optwin0-1),BC_forecast1(:,optwin1-1),BC_forecast2(:,optwin2-1),BC_forecast3(:,optwin3-1)];

save BC_forecast.mat opt_BC_forecast -mat

%% Mincer-Zarnowitz equation을 이용한 bias corrected prediction
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Allocating empty matrices for "bias corrected forecasts with h = 0,1"%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BC_forecast0 = NaN(T,max_window0-1);
BC_forecast1 = NaN(T,max_window1-1);

% New predictions with alternative AR(1) model, and computing rmse of the
% alternative for each window size.
% We use past w data points (data point = pair of original and lagged
% values).

W0 = [realized_cpi,cpi(:,2),array_num];
W0 = rmmissing(W0);
W1 = [realized_cpi,cpi(:,3),array_num];
W1 = rmmissing(W1);


BC_forecast0 = MZ_BC(W0,BC_forecast0,cpi0,T,max_window0,0);
BC_forecast1 = MZ_BC(W1,BC_forecast1,cpi1,T,max_window1,1);


% We restrict the validation set to be 2012-2024, to preserve the data set
% size for each window size w. For earlier periods, there are missing
% points. Hence, to evaluate and compare fairly the window sizes we choose
% the data period that is balanced.
subsample0 = time >=2000.5 & time <=2024;   
rmse0 = rmse(BC_forecast0(subsample0,:),realized_cpi(subsample0,1),1,"omitmissing");
rmse0_bok = rmse(cpi0(subsample0,1),realized_cpi(subsample0,1),1,"omitmissing");
rrmse0 = rmse0./rmse0_bok;
subsample1 = time >=2013.5 & time <=2024;
rmse1 = rmse(BC_forecast1(subsample1,:),realized_cpi(subsample1,:),1,"omitmissing");
rmse1_bok = rmse(cpi1(subsample1,1),realized_cpi(subsample1,1),1,"omitmissing");
rrmse1 = rmse1./rmse1_bok;

% for h = 2,3

BC_forecast2 = NaN(T,max_window2-1);
BC_forecast3 = NaN(T,max_window3-1);
W2 = [realized_cpi,cpi(:,4),array_num];
W2 = rmmissing(W2);
W3 = [realized_cpi,cpi(:,5),array_num];
W3 = rmmissing(W3);

BC_forecast2 = MZ_BC(W2,BC_forecast2,cpi2,T,max_window2,2);
BC_forecast3 = MZ_BC(W3,BC_forecast3,cpi3,T,max_window3,3);

subsample2 = time >=2003 & time <=2024.5;
subsample3 = time >=2014.5 & time <=2024.5;

rmse2 = rmse(BC_forecast2(subsample2,:),realized_cpi(subsample2,1),1,"omitmissing");
rmse2_bok = rmse(cpi2(subsample2,1),realized_cpi(subsample2,1),1,"omitmissing");
rrmse2 = rmse2./rmse2_bok;

rmse3 = rmse(BC_forecast3(subsample3,:),realized_cpi(subsample3,1),1,"omitmissing");
rmse3_bok = rmse(cpi3(subsample3,1),realized_cpi(subsample3,1),1,"omitmissing");
rrmse3 = rmse3./rmse3_bok;


window0 = 2:max_window0;  % array of window sizes from 2 to max_window => for plotting rmse
window1 = 2:max_window1;
window2 = 2:max_window2;
window3 = 2:max_window3;

subplot(2,2,1)
yyaxis right
ylim([2.5 4.5])
plot(window0,rrmse0(1,:),'r-x'); hold on;
xticks ([4 5 10 15 20])
xlim([4 max_window0])
subplot(2,2,2)
plot(window1,rrmse1(1,:),'r-x'); hold on;
xticks ([4 5 10 15 20])
xlim([4 max_window1])
subplot(2,2,3)
plot(window2,rrmse2(1,:),'r-x'); hold on;
xticks ([4 5 10 15 20])
xlim([4 max_window2])
subplot(2,2,4)
plot(window3,rrmse3(1,:),'r-x'); hold on;
xticks ([4 5 10 15 20])
xlim([4 max_window3])

%% Mean Error Bias Correction
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Allocating empty matrices for "bias corrected forecasts with h = 0,1"%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

BC_forecast0 = NaN(T,max_window0);
BC_forecast1 = NaN(T,max_window1);

% New predictions with alternative AR(1) model, and computing rmse of the
% alternative for each window size.
% We use past w data points (data point = pair of original and lagged
% values).

W0 = [ecpi(:,2),array_num];
W0 = rmmissing(W0);
W1 = [ecpi(:,3),array_num];
W1 = rmmissing(W1);


BC_forecast0 = ME_BC(W0,BC_forecast0,cpi0,T,max_window0,0);
BC_forecast1 = ME_BC(W1,BC_forecast1,cpi1,T,max_window1,1);


% We restrict the validation set to be 2012-2024, to preserve the data set
% size for each window size w. For earlier periods, there are missing
% points. Hence, to evaluate and compare fairly the window sizes we choose
% the data period that is balanced.
subsample0 = time >=2000.5 & time <=2024;   
rmse0 = rmse(BC_forecast0(subsample0,:),realized_cpi(subsample0,1),1,"omitmissing");
rmse0_bok = rmse(cpi0(subsample0,1),realized_cpi(subsample0,1),1,"omitmissing");
rrmse0 = rmse0./rmse0_bok;
subsample1 = time >=2013.5 & time <=2024;
rmse1 = rmse(BC_forecast1(subsample1,:),realized_cpi(subsample1,:),1,"omitmissing");
rmse1_bok = rmse(cpi1(subsample1,1),realized_cpi(subsample1,1),1,"omitmissing");
rrmse1 = rmse1./rmse1_bok;

% for h = 2,3

BC_forecast2 = NaN(T,max_window2);
BC_forecast3 = NaN(T,max_window3);
W2 = [ecpi(:,4),array_num];
W2 = rmmissing(W2);
W3 = [ecpi(:,5),array_num];
W3 = rmmissing(W3);

BC_forecast2 = ME_BC(W2,BC_forecast2,cpi2,T,max_window2,2);
BC_forecast3 = ME_BC(W3,BC_forecast3,cpi3,T,max_window3,3);

subsample2 = time >=2003 & time <=2024.5;
subsample3 = time >=2014.5 & time <=2024.5;

rmse2 = rmse(BC_forecast2(subsample2,:),realized_cpi(subsample2,1),1,"omitmissing");
rmse2_bok = rmse(cpi2(subsample2,1),realized_cpi(subsample2,1),1,"omitmissing");
rrmse2 = rmse2./rmse2_bok;

rmse3 = rmse(BC_forecast3(subsample3,:),realized_cpi(subsample3,1),1,"omitmissing");
rmse3_bok = rmse(cpi3(subsample3,1),realized_cpi(subsample3,1),1,"omitmissing");
rrmse3 = rmse3./rmse3_bok;

window0 = 1:max_window0;  % array of window sizes from 2 to max_window => for plotting rmse
window1 = 1:max_window1;
window2 = 1:max_window2;
window3 = 1:max_window3;


subplot(2,2,1)
yyaxis left
plot(window0,rrmse0(1,:),'b-^'); hold on;
legend 'AR(1)' 'Mean Error' 'Mincer-Zarnowitz' Location 'northeast'
subplot(2,2,2)
plot(window1,rrmse1(1,:),'b-^'); hold on;
legend 'AR(1)' 'Mincer-Zarnowitz' 'Mean Error' Location 'northeast'
subplot(2,2,3)
plot(window2,rrmse2(1,:),'b-^'); hold on;
legend 'AR(1)' 'Mincer-Zarnowitz' 'Mean Error' Location 'northeast'
subplot(2,2,4)
plot(window3,rrmse3(1,:),'b-^'); hold on;
legend 'AR(1)' 'Mincer-Zarnowitz' 'Mean Error' Location 'northeast'

