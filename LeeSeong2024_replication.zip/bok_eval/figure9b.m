clear
clc

load eval_data.mat

time = evaldata.time;

eu0 = -evaldata.unemp0+evaldata.realized_unemp;
eu1 = -evaldata.unemp1+evaldata.realized_unemp;
eu2 = -evaldata.unemp2+evaldata.realized_unemp;
eu3 = -evaldata.unemp3+evaldata.realized_unemp;
eu4 = -evaldata.unemp4+evaldata.realized_unemp;
eu5 = -evaldata.unemp5+evaldata.realized_unemp;
eu6 = -evaldata.unemp6+evaldata.realized_unemp;
eu = [eu6,eu5,eu4,eu3,eu3,eu2,eu1,eu0];

figure("Position",[300,300,1000,500])
bar(time,eu(:,end-3:end))
pbaspect([2 1 1])
xlim([2012,2025])
ylim([-1,1])
title 'Unemployment rate Forecast Error'
xticks([2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025])
legend 'h=3' 'h=2' 'h=1' 'h=0'
grid on;