clear
clc
load BC_forecast.mat
load eval_data.mat

% Code for Figure 8
% Compare RMSE of BoK forecast and that of AR(1) BC forecast

time = evaldata.time;
realized_cpi = evaldata.realized_cpi;
cpi0 = evaldata.cpi0(21:end,1);
cpi1 = evaldata.cpi1(30:end,1);
cpi2 = evaldata.cpi2(23:end,1);
cpi3 = evaldata.cpi3(32:end,1);
ar_cpi0 = opt_BC_forecast(21:end,1);
ar_cpi1 = opt_BC_forecast(30:end,2);
ar_cpi2 = opt_BC_forecast(23:end,3);
ar_cpi3 = opt_BC_forecast(32:end,4);

time0 = evaldata.time(21:end,1);
realized_cpi0 = evaldata.realized_cpi(21:end,1);
nan0 = 1-zeros(size(cpi0,1),1).*cpi0;
bok_rmse0 = cumsum((realized_cpi0-cpi0).^2,1,"omitmissing")./cumsum(nan0,1,"omitmissing");
nan0 = 1-zeros(size(ar_cpi0,1),1).*ar_cpi0;
ar_rmse0 = cumsum((realized_cpi0-ar_cpi0).^2,1,"omitmissing")./cumsum(nan0,1,"omitmissing");

time1 = evaldata.time(30:end,1);
realized_cpi1 = evaldata.realized_cpi(30:end,1);
nan1 = 1-zeros(size(cpi1,1),1).*cpi1;
bok_rmse1 = cumsum((realized_cpi1-cpi1).^2,1,"omitmissing")./cumsum(nan1,1,"omitmissing");
nan1 = 1-zeros(size(ar_cpi1,1),1).*ar_cpi1;
ar_rmse1 = cumsum((realized_cpi1-ar_cpi1).^2,1,"omitmissing")./cumsum(nan1,1,"omitmissing");

time2 = evaldata.time(23:end,1);
realized_cpi2 = evaldata.realized_cpi(23:end,1);
nan2 = 1-zeros(size(cpi2,1),1).*cpi2;
bok_rmse2 = cumsum((realized_cpi2-cpi2).^2,1,"omitmissing")./cumsum(nan2,1,"omitmissing");
nan2 = 1-zeros(size(ar_cpi2,1),1).*ar_cpi2;
ar_rmse2 = cumsum((realized_cpi2-ar_cpi2).^2,1,"omitmissing")./cumsum(nan2,1,"omitmissing");

time3 = evaldata.time(32:end,1);
realized_cpi3 = evaldata.realized_cpi(32:end,1);
nan3 = 1-zeros(size(cpi3,1),1).*cpi3;
bok_rmse3 = cumsum((realized_cpi3-cpi3).^2,1,"omitmissing")./cumsum(nan3,1,"omitmissing");
nan3 = 1-zeros(size(ar_cpi3,1),1).*ar_cpi3;
ar_rmse3 = cumsum((realized_cpi3-ar_cpi3).^2,1,"omitmissing")./cumsum(nan3,1,"omitmissing");


figure("Position",[100 100 1200 800])
subplot(2,2,1)
plot(time0,ar_rmse0,'k-o'); hold on;
plot(time0,bok_rmse0,'r-^');
xlim([2008,2026])
xticks([2010,2015,2020,2025])
ylabel 'RMSE'
legend 'AR(1)' 'BoK'
title 'h=0, Window Size=20'
subplot(2,2,2)
plot(time1,ar_rmse1,'k-o'); hold on;
plot(time1,bok_rmse1,'r-^');
xlim([2013,2026])
xticks([2015,2020,2025])
ylabel 'RMSE'
legend 'AR(1)' 'BoK'
title 'h=1, Window Size=20'
subplot(2,2,3)
plot(time2,ar_rmse2,'k-o'); hold on;
plot(time2,bok_rmse2,'r-^');
xlim([2008,2026])
xticks([2010,2015,2020,2025])
ylabel 'RMSE'
legend 'AR(1)' 'BoK'
title 'h=2, Window Size=20'
subplot(2,2,4)
plot(time3,ar_rmse3,'k-o'); hold on;
plot(time3,bok_rmse3,'r-^');
xlim([2013,2026])
xticks([2015,2020,2025])
ylabel 'RMSE'
legend 'AR(1)' 'BoK'
title 'h=3, Window Size=20'
