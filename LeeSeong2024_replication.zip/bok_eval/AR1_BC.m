function BiasCorrection = AR1_BC(W,BC_forecast,forecast,f_error,T,max_window,h)
    if h < 2
        u = 1;
    elseif h < 4
        u = 2;
    else
        u = 3;
    end

    for w = 2:max_window
        for t = 1:T
            % if there is no forecast, then do nothing. Then the corresponding 
            % BC_forecast will remain NaN.
            if isnan(forecast(t,1))
                disp('No forecast at t=');disp(t)
                continue
            % if there is, then we check whether we have enough data points. 
            % We first search for the latest data point.
            else
                k=1; % Initializing the array number.
                cur_diff = (t-u)-W(k,3); % If cur_diff is negative, it means that 
                % we have crossed the threshold t-u(available info set at t).
                if cur_diff < 0
                    k=0; % k=0 means that we failed to find any data point.
                else
                    while k < t
                        nex_diff = (t-u)-W(k+1,3);
                        if nex_diff < 0
                            break
                        else
                            cur_diff = nex_diff;
                            k = k+1;
                        end
                    end
                    if k == t-u+1   % If the while loop has arrived the last loop, 
                        % then we adjust k.
                        k = k-1;
                    end
                end
                % Now we have the latest observation k. Next,
                % we check whether we lack of observations.
                if (k == 0)
                    disp('No data points to estimate AR(1) at t=');disp([t,k,w])
                    continue
                % If we have enough data points to estimate AR(1) coef alpha,
                % then
                else
                    if k < w-1
                        disp('With smaller sample size of ');disp(k)
                        Y = W(1:k,1);
                        X = W(1:k,2);
                        alpha0 = (X'*X)\(X'*Y);
                    else
                        Y = W(k-(w-1)+1:k,1);
                        X = W(k-(w-1)+1:k,2);
                        alpha0 = (X'*X)\(X'*Y);

                    end
                    % To project current forecast error, we first search for 
                    % the latest forecast error
                    s=W(k,3); % Initializing the array number. 
                    % We start at W(k,3), because this is what is guaranteed. 
                    % There could exist more recent error (counted as 
                    % a missing value because it does not have corresponding lag value).
                    cur_diff = (t-u)-f_error(s,1); % If cur_diff is zero, it means that 
                    % we are already are using up-to-date
                    % information(\Omega_{t-u}).
                    if cur_diff == 0
                    else
                        while s < t
                            nex_diff = (t-u)-f_error(s+1,1);
                            if nex_diff < 0
                                break
                            else
                                cur_diff = nex_diff;
                                s = s+1;
                            end
                        end
                        if s == t-u+1   % If the while loop has arrived the last loop, 
                            % then we adjust s.
                            s = s-1;
                        end
                    end
                    
                    % We now have the latest forecast error at s. Using this
                    % error we project current forecast error.
                    e0 = f_error(s,2)*alpha0;
                    BC_forecast(t,w-1) = round(forecast(t,1)-e0,1);                
                end
            end
        end
    end
    
    BiasCorrection=BC_forecast;

end