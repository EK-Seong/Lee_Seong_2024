clear
clc
load cpi_plot.mat


% xfill = [cpiinflation.t; flipud(cpiinflation.t)];
% yfill = [cpiinflation.ITup; flipud(cpiinflation.ITlo)];
% hold on;

figure("Position",[300,300,1000,500])
fillcolor = [0.9 0.9 0.9];hold on;
fill(xfill, yfill, fillcolor);
plot(cpiinflation.t,cpiinflation.IT,'k:');
plot(cpiinflation.t,cpiinflation.realized,'r-o','DisplayName','cpiinflation.realized');hold on;
plot(cpiinflation.t,cpiinflation.VarName3,'b--x');
plot(cpiinflation.t,cpiinflation.VarName4,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName5,'b--x');
plot(cpiinflation.t,cpiinflation.VarName6,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName7,'b--x');
plot(cpiinflation.t,cpiinflation.VarName8,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName9,'b--x');
plot(cpiinflation.t,cpiinflation.VarName10,'b--x');
plot(cpiinflation.t,cpiinflation.VarName11,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName12,'b--x');
plot(cpiinflation.t,cpiinflation.VarName13,'b--x');
plot(cpiinflation.t,cpiinflation.VarName14,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName15,'b--x');
plot(cpiinflation.t,cpiinflation.VarName16,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName17,'b--x');
plot(cpiinflation.t,cpiinflation.VarName18,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName19,'b--x');
plot(cpiinflation.t,cpiinflation.VarName20,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName21,'b--x');
plot(cpiinflation.t,cpiinflation.VarName22,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName23,'b--x');
plot(cpiinflation.t,cpiinflation.VarName24,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName25,'b--x');
plot(cpiinflation.t,cpiinflation.VarName26,'b--x');
plot(cpiinflation.t,cpiinflation.VarName27,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName28,'b--x');
plot(cpiinflation.t,cpiinflation.VarName29,'b--x');
plot(cpiinflation.t,cpiinflation.VarName30,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName31,'b--x');
plot(cpiinflation.t,cpiinflation.VarName32,'b--x');
plot(cpiinflation.t,cpiinflation.VarName33,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName34,'b--x');
plot(cpiinflation.t,cpiinflation.VarName35,'b--x');
plot(cpiinflation.t,cpiinflation.VarName36,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName37,'b--x');
plot(cpiinflation.t,cpiinflation.VarName38,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName39,'b--x');
plot(cpiinflation.t,cpiinflation.VarName40,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName41,'b--x');
plot(cpiinflation.t,cpiinflation.VarName42,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName43,'b--x');
plot(cpiinflation.t,cpiinflation.VarName44,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName45,'b--x');
plot(cpiinflation.t,cpiinflation.VarName46,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName47,'b--x');
plot(cpiinflation.t,cpiinflation.VarName48,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName49,'b--x');
plot(cpiinflation.t,cpiinflation.VarName50,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName51,'b--x');
plot(cpiinflation.t,cpiinflation.VarName52,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName53,'b--x');
plot(cpiinflation.t,cpiinflation.VarName54,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName55,'b--x');
plot(cpiinflation.t,cpiinflation.VarName56,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName57,'b--x');
plot(cpiinflation.t,cpiinflation.VarName58,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName59,'b--x');
plot(cpiinflation.t,cpiinflation.VarName60,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName61,'b--x');
plot(cpiinflation.t,cpiinflation.VarName62,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName63,'b--x');
plot(cpiinflation.t,cpiinflation.VarName64,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName65,'b--x');
plot(cpiinflation.t,cpiinflation.VarName66,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName67,'b--x');
plot(cpiinflation.t,cpiinflation.VarName68,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName69,'b--x');
plot(cpiinflation.t,cpiinflation.VarName70,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName71,'b--x');
plot(cpiinflation.t,cpiinflation.VarName72,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName73,'b--x');
plot(cpiinflation.t,cpiinflation.VarName74,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName75,'b--x');
plot(cpiinflation.t,cpiinflation.VarName76,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName77,'b--x');
plot(cpiinflation.t,cpiinflation.VarName78,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName79,'b--x');
plot(cpiinflation.t,cpiinflation.VarName80,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName81,'b--x');
plot(cpiinflation.t,cpiinflation.VarName82,'c-.^');
plot(cpiinflation.t,cpiinflation.VarName83,'b--x');
hold off;
xlim([2012,2026])
ylim([0,6])
title 'CPI inflation rate'
xticks([2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025,2026])
pbaspect([1000 500 100])
legend 'Target range' 'Target point' 'Actual inflation rate' 'Second issue of the half-year' 'First issue of the half-year' Location northwest



fig = figure("Position",[300,300,1000,500]);
fillcolor = [0.9 0.9 0.9];hold on;
p = fill(xfill, yfill, fillcolor);
plot(cpiinflation.t,cpiinflation.core,'b-.','DisplayName','cpiinflation.core');hold on;
plot(cpiinflation.t,cpiinflation.cpi,'r','DisplayName','cpiinflation.cpi');hold on;
plot(cpiinflation.t,cpiinflation.IT,'k--'); hold off;
xlim([1999,2025])
ylim([0,6])
pbaspect([1000 500 100])
legend 'Target range' 'Core Inflation' 'CPI Inflation' 'Target point' Location northwest
title 'Inflation Targets in Korea'



