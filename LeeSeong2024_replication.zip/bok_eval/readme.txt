- version of the Matlab.exe : 2023a
- version of the Stata.exe : 18

figure1-10.m : replicate Figures in the paper
table4.do, table5_6.do : replicate Tables in the paper

- To run figure8.m, you need to run figure7.m, first

AR1_BC.m : function for AR(1) bias correction
ME_BC.m : function for Mean-error bias correction
MZ_BC.m : function for Mincer-Zarnowitz bias correction

- other -xlsx, -mat, -dat files : data for each relevant -m, -do files

rawdata folder contains : -xlsx files of the raw data