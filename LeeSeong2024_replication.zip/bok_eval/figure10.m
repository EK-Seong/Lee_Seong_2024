clear
clc

load eval_data.mat

time = evaldata.time;
array_num = (1:size(time,1))';

ecpi0 = evaldata.cpi0-evaldata.realized_cpi;
ecpi1 = evaldata.cpi1-evaldata.realized_cpi;
ecpi2 = evaldata.cpi2-evaldata.realized_cpi;
ecpi3 = evaldata.cpi3-evaldata.realized_cpi;
ecpi4 = evaldata.cpi4-evaldata.realized_cpi;
ecpi5 = evaldata.cpi5-evaldata.realized_cpi;
ecpi6 = evaldata.cpi6-evaldata.realized_cpi;
ecpi = [array_num,ecpi0,ecpi1,ecpi2,ecpi3,ecpi4,ecpi5];
lag_ecpi = lagmatrix(ecpi,1);

ecpi0 = [array_num,ecpi0];
ecpi1 = [array_num,ecpi1];
ecpi2 = [array_num,ecpi2];
ecpi3 = [array_num,ecpi3];
ecpi4 = [array_num,ecpi4];
ecpi5 = [array_num,ecpi5];


cpi0 = evaldata.cpi0;
cpi1 = evaldata.cpi1;
cpi2 = evaldata.cpi2;
cpi3 = evaldata.cpi3;
cpi4 = evaldata.cpi4;
cpi5 = evaldata.cpi5;
cpi = [time,cpi0,cpi1,cpi2,cpi3,cpi4,cpi5];

realized_cpi = evaldata.realized_cpi;

T = size(time,1);       % allocating sample size to T

% Inflation target variable IT
IT = NaN(size(evaldata.time,1),1);
d = evaldata.time < 2016;
IT = d*3 +(1-d)*2;
IT(3:4,1) = 2.5;
% State variable for each horizon

% state0 = evaldata.q_infl1 <= IT;
% state1 = lagmatrix(evaldata.q_infl2,1) <= lagmatrix(IT,1);
% state2 = lagmatrix(evaldata.q_infl1,1) <= lagmatrix(IT,1);
% state3 = lagmatrix(evaldata.q_infl2,2) <= lagmatrix(IT,2);

state0 = lagmatrix(realized_cpi,1) <= lagmatrix(IT,1);
state1 = lagmatrix(realized_cpi,1) <= lagmatrix(IT,1);
state2 = lagmatrix(realized_cpi,2) <= lagmatrix(IT,2);
state3 = lagmatrix(realized_cpi,2) <= lagmatrix(IT,2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%% State-dependent AR(1) Strategy


max_window0 = 30;        % allocating maximum window size
max_window1 = 30;
max_window2 = 30;
max_window3 = 30;
window0 = 3:max_window0;  % array of window sizes from 2 to max_window => for plotting rmse
window1 = 3:max_window1;
window2 = 3:max_window2;
window3 = 3:max_window3;

BC_forecast0 = NaN(T,max_window0-2);
BC_forecast1 = NaN(T,max_window1-2);

W0 = [ecpi(:,2),lag_ecpi(:,2),state0,array_num];
W0 = rmmissing(W0);
W1 = [ecpi(:,3),lag_ecpi(:,3),state1,array_num];
W1 = rmmissing(W1);

BC_forecast0 = SD_AR1_BC(W0,BC_forecast0,cpi0,ecpi0,state0,T,max_window0,0);
BC_forecast1 = SD_AR1_BC(W1,BC_forecast1,cpi1,ecpi1,state1,T,max_window1,1);


% We restrict the validation set to be 2012-2024, to preserve the data set
% size for each window size w. For earlier periods, there are missing
% points. Hence, to evaluate and compare fairly the window sizes we choose
% the data period that is balanced.

subsample0 = time >=2000.5 & time <=2024;   
rmse0 = rmse(BC_forecast0(subsample0,:),realized_cpi(subsample0,1),1,"omitmissing");
rmse0_bok = rmse(cpi0(subsample0,1),realized_cpi(subsample0,1),1,"omitmissing");
rrmse0 = rmse0./rmse0_bok;

subsample1 = time >=2013.5 & time <=2024;
rmse1 = rmse(BC_forecast1(subsample1,:),realized_cpi(subsample1,:),1,"omitmissing");
rmse1_bok = rmse(cpi1(subsample1,1),realized_cpi(subsample1,1),1,"omitmissing");
rrmse1 = rmse1./rmse1_bok;

% for h = 2,3

BC_forecast2 = NaN(T,max_window2-2);
BC_forecast3 = NaN(T,max_window3-2);

W2 = [ecpi(:,4),lag_ecpi(:,4),state2,array_num];
W2 = rmmissing(W2);
W3 = [ecpi(:,5),lag_ecpi(:,5),state3,array_num];
W3 = rmmissing(W3);

BC_forecast2 = SD_AR1_BC(W2,BC_forecast2,cpi2,ecpi2,state2,T,max_window2,2);
BC_forecast3 = SD_AR1_BC(W3,BC_forecast3,cpi3,ecpi3,state3,T,max_window3,3);

subsample2 = time >=2003 & time <=2024.5;
subsample3 = time >=2014.5 & time <=2024.5;

rmse2 = rmse(BC_forecast2(subsample2,:),realized_cpi(subsample2,1),1,"omitmissing");
rmse2_bok = rmse(cpi2(subsample2,1),realized_cpi(subsample2,1),1,"omitmissing");
rrmse2 = rmse2./rmse2_bok;

rmse3 = rmse(BC_forecast3(subsample3,:),realized_cpi(subsample3,1),1,"omitmissing");
rmse3_bok = rmse(cpi3(subsample3,1),realized_cpi(subsample3,1),1,"omitmissing");
rrmse3 = rmse3./rmse3_bok;


figure("Position",[100 100 1200 800])
subplot(2,2,1)
plot(window0,rrmse0(1,:),'k-o'); hold on;
grid on;
xticks ([5 10 15 20 25 30])
xlim([5 max_window0])
ylim([0.6 1.4])
ylabel 'RMSE'
title 'h=0'
subplot(2,2,2)
plot(window1,rrmse1(1,:),'k-o'); hold on;
grid on;
xticks ([5 10 15 20 25 30])
xlim([5 max_window1])
ylim([0.8 1.6])
title 'h=1'
subplot(2,2,3)
plot(window2,rrmse2(1,:),'k-o'); hold on;
grid on;
xticks ([5 10 15 20 25 30])
xlim([5 max_window2])
ylim([0.7 1.5])
ylabel 'RMSE'
xlabel 'window size'
title 'h=2'
subplot(2,2,4)
plot(window3,rrmse3(1,:),'k-o'); hold on;
grid on;
ylim([0.9 1.7])
xticks ([5 10 15 20 25 30])
xlim([5 max_window3])
xlabel 'window size'
title 'h=3'

%% State Dependent Mean Error Bias Correction
clc

BC_forecast0 = NaN(T,max_window0-1);
BC_forecast1 = NaN(T,max_window1-1);

W0 = [ecpi(:,2),state0,array_num];
W0 = rmmissing(W0);
W1 = [ecpi(:,3),state1,array_num];
W1 = rmmissing(W1);

BC_forecast0 = SD_ME_BC(W0,BC_forecast0,cpi0,state0,T,max_window0,0);
BC_forecast1 = SD_ME_BC(W1,BC_forecast1,cpi1,state1,T,max_window1,1);

% We restrict the validation set to be 2012-2024, to preserve the data set
% size for each window size w. For earlier periods, there are missing
% points. Hence, to evaluate and compare fairly the window sizes we choose
% the data period that is balanced.

subsample0 = time >=2000.5 & time <=2024;   
rmse0 = rmse(BC_forecast0(subsample0,:),realized_cpi(subsample0,1),1,"omitmissing");
rmse0_bok = rmse(cpi0(subsample0,1),realized_cpi(subsample0,1),1,"omitmissing");
rrmse0 = rmse0./rmse0_bok;

subsample1 = time >=2013.5 & time <=2024;
rmse1 = rmse(BC_forecast1(subsample1,:),realized_cpi(subsample1,:),1,"omitmissing");
rmse1_bok = rmse(cpi1(subsample1,1),realized_cpi(subsample1,1),1,"omitmissing");
rrmse1 = rmse1./rmse1_bok;

% for h = 2,3

BC_forecast2 = NaN(T,max_window2-1);
BC_forecast3 = NaN(T,max_window3-1);
W2 = [ecpi(:,4),state2,array_num];
W2 = rmmissing(W2);
W3 = [ecpi(:,5),state3,array_num];
W3 = rmmissing(W3);

BC_forecast2 = SD_ME_BC(W2,BC_forecast2,cpi2,state2,T,max_window2,2);
BC_forecast3 = SD_ME_BC(W3,BC_forecast3,cpi3,state3,T,max_window3,3);

subsample2 = time >=2003 & time <=2024.5;
subsample3 = time >=2014.5 & time <=2024.5;

rmse2 = rmse(BC_forecast2(subsample2,:),realized_cpi(subsample2,1),1,"omitmissing");
rmse2_bok = rmse(cpi2(subsample2,1),realized_cpi(subsample2,1),1,"omitmissing");
rrmse2 = rmse2./rmse2_bok;

rmse3 = rmse(BC_forecast3(subsample3,:),realized_cpi(subsample3,1),1,"omitmissing");
rmse3_bok = rmse(cpi3(subsample3,1),realized_cpi(subsample3,1),1,"omitmissing");
rrmse3 = rmse3./rmse3_bok;


window0 = 2:max_window0;  % array of window sizes from 2 to max_window => for plotting rmse
window1 = 2:max_window1;
window2 = 2:max_window2;
window3 = 2:max_window3;


subplot(2,2,1)
plot(window0,rrmse0(1,:),'r-x'); hold on;
subplot(2,2,2)
plot(window1,rrmse1(1,:),'r-x'); hold on;
subplot(2,2,3)
plot(window2,rrmse2(1,:),'r-x'); hold on;
subplot(2,2,4)
ylim([0.9 1.7])
plot(window3,rrmse3(1,:),'r-x'); hold on;

%% State dependent Mincer-Zarnowitz Bias correction
clc

max_window0 = 30;
max_window1 = 30;
max_window2 = 30;
max_window3 = 30;


BC_forecast0 = NaN(T,max_window0-3);
BC_forecast1 = NaN(T,max_window1-3);

W0 = [realized_cpi,cpi(:,2),state0,array_num];
W0 = rmmissing(W0);
W1 = [realized_cpi,cpi(:,3),state1,array_num];
W1 = rmmissing(W1);


BC_forecast0 = SD_MZ_BC(W0,BC_forecast0,cpi0,state0,T,max_window0,0);
BC_forecast1 = SD_MZ_BC(W1,BC_forecast1,cpi1,state1,T,max_window1,1);

subsample0 = time >=2000.5 & time <=2024;   
rmse0 = rmse(BC_forecast0(subsample0,:),realized_cpi(subsample0,1),1,"omitmissing");
rmse0_bok = rmse(cpi0(subsample0,1),realized_cpi(subsample0,1),1,"omitmissing");
rrmse0 = rmse0./rmse0_bok;
subsample1 = time >=2013.5 & time <=2024;
rmse1 = rmse(BC_forecast1(subsample1,:),realized_cpi(subsample1,:),1,"omitmissing");
rmse1_bok = rmse(cpi1(subsample1,1),realized_cpi(subsample1,1),1,"omitmissing");
rrmse1 = rmse1./rmse1_bok;

% for h = 2,3

BC_forecast2 = NaN(T,max_window2-3);
BC_forecast3 = NaN(T,max_window3-3);
W2 = [realized_cpi,cpi(:,4),state2,array_num];
W2 = rmmissing(W2);
W3 = [realized_cpi,cpi(:,5),state3,array_num];
W3 = rmmissing(W3);

BC_forecast2 = SD_MZ_BC(W2,BC_forecast2,cpi2,state2,T,max_window2,2);
BC_forecast3 = SD_MZ_BC(W3,BC_forecast3,cpi3,state3,T,max_window3,3);

subsample2 = time >=2003 & time <=2024.5;
subsample3 = time >=2014.5 & time <=2024.5;

rmse2 = rmse(BC_forecast2(subsample2,:),realized_cpi(subsample2,1),1,"omitmissing");
rmse2_bok = rmse(cpi2(subsample2,1),realized_cpi(subsample2,1),1,"omitmissing");
rrmse2 = rmse2./rmse2_bok;

rmse3 = rmse(BC_forecast3(subsample3,:),realized_cpi(subsample3,1),1,"omitmissing");
rmse3_bok = rmse(cpi3(subsample3,1),realized_cpi(subsample3,1),1,"omitmissing");
rrmse3 = rmse3./rmse3_bok;

window0 = 4:max_window0;  % array of window sizes from 2 to max_window => for plotting rmse
window1 = 4:max_window1;
window2 = 4:max_window2;
window3 = 4:max_window3;

subplot(2,2,1)
yyaxis right
ylim([2.45 3.15])
plot(window0,rrmse0(1,:),'b-^'); hold on;
subplot(2,2,2)
plot(window1,rrmse1(1,:),'b-^'); hold on;
subplot(2,2,3)
plot(window2,rrmse2(1,:),'b-^'); hold on;
subplot(2,2,4)
plot(window3,rrmse3(1,:),'b-^'); hold on;

%% AR(1) with constant
clc

BC_forecast0 = NaN(T,max_window0-2);
BC_forecast1 = NaN(T,max_window1-2);


W0 = [ecpi(:,2),lag_ecpi(:,2),array_num];
W0 = rmmissing(W0);
W1 = [ecpi(:,3),lag_ecpi(:,3),array_num];
W1 = rmmissing(W1);


BC_forecast0 = AR1_BC_with_const(W0,BC_forecast0,cpi0,ecpi0,T,max_window0,0);
BC_forecast1 = AR1_BC_with_const(W1,BC_forecast1,cpi1,ecpi1,T,max_window1,1);

subsample0 = time >=2000.5 & time <=2024;   
subsample1 = time >=2013.5 & time <=2024;

rmse0 = rmse(BC_forecast0(subsample0,:),realized_cpi(subsample0,1),1,"omitmissing");
rmse0_bok = rmse(cpi0(subsample0,1),realized_cpi(subsample0,1),1,"omitmissing");
rrmse0 = rmse0./rmse0_bok;

rmse1 = rmse(BC_forecast1(subsample1,:),realized_cpi(subsample1,:),1,"omitmissing");
rmse1_bok = rmse(cpi1(subsample1,1),realized_cpi(subsample1,1),1,"omitmissing");
rrmse1 = rmse1./rmse1_bok;

% for h = 2,3

BC_forecast2 = NaN(T,max_window2-2);
BC_forecast3 = NaN(T,max_window3-2);
W2 = [ecpi(:,4),lag_ecpi(:,4),array_num];
W2 = rmmissing(W2);
W3 = [ecpi(:,5),lag_ecpi(:,5),array_num];
W3 = rmmissing(W3);

BC_forecast2 = AR1_BC_with_const(W2,BC_forecast2,cpi2,ecpi2,T,max_window2,2);
BC_forecast3 = AR1_BC_with_const(W3,BC_forecast3,cpi3,ecpi3,T,max_window3,3);

subsample2 = time >=2003 & time <=2024.5;
subsample3 = time >=2014.5 & time <=2024.5;

rmse2 = rmse(BC_forecast2(subsample2,:),realized_cpi(subsample2,1),1,"omitmissing");
rmse2_bok = rmse(cpi2(subsample2,1),realized_cpi(subsample2,1),1,"omitmissing");
rrmse2 = rmse2./rmse2_bok;

rmse3 = rmse(BC_forecast3(subsample3,:),realized_cpi(subsample3,1),1,"omitmissing");
rmse3_bok = rmse(cpi3(subsample3,1),realized_cpi(subsample3,1),1,"omitmissing");
rrmse3 = rmse3./rmse3_bok;

window0 = 3:max_window0;  % array of window sizes from 2 to max_window => for plotting rmse
window1 = 3:max_window1;
window2 = 3:max_window2;
window3 = 3:max_window3;

subplot(2,2,1)
yyaxis left
plot(window0,rrmse0(1,:),'y-*'); hold on;
legend 'SD-AR(1)' 'SD-ME'  'AR(1) with constant' 'SD-MZ' Location 'northeast'
subplot(2,2,2)
plot(window1,rrmse1(1,:),'y-*'); hold on;
legend 'SD-AR(1)' 'SD-ME' 'SD-MZ' 'AR(1) with constant' Location 'northeast'
subplot(2,2,3)
plot(window2,rrmse2(1,:),'y-*'); hold on;
legend 'SD-AR(1)' 'SD-ME' 'SD-MZ' 'AR(1) with constant' Location 'northeast'
subplot(2,2,4)
plot(window3,rrmse3(1,:),'y-*'); hold on;
legend  'SD-AR(1)' 'SD-ME' 'SD-MZ' 'AR(1) with constant'  Location 'northeast'